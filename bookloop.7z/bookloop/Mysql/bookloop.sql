/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : bookloop

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2016-02-16 19:58:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `bookloop_book`
-- ----------------------------
DROP TABLE IF EXISTS `bookloop_book`;
CREATE TABLE `bookloop_book` (
  `book_id` int(20) NOT NULL,
  `description` text COMMENT '书的描述',
  `image` varchar(20) DEFAULT NULL COMMENT '书的图片url',
  `name` varchar(30) NOT NULL,
  `author` varchar(30) DEFAULT NULL,
  `publishing_house` varchar(50) DEFAULT NULL COMMENT '出版社',
  `publishing_time` date DEFAULT NULL COMMENT '出版时间',
  `price_make` float(10,2) DEFAULT NULL COMMENT '定价(之前书的价格）',
  `price` float(10,2) NOT NULL COMMENT '卖家的出价',
  `isbn` int(20) DEFAULT NULL COMMENT '国际标准书号',
  `type` tinyint(2) NOT NULL COMMENT '书的类型',
  `user_id` int(10) NOT NULL COMMENT '用户id即卖家的id',
  `school` varchar(20) DEFAULT NULL COMMENT '院系',
  `address` varchar(50) DEFAULT NULL COMMENT '地址',
  `qq` int(20) DEFAULT NULL COMMENT 'qq号码',
  `phone` int(15) DEFAULT NULL COMMENT '电话号码',
  `left_comment` varchar(255) DEFAULT NULL COMMENT '留言，存储每条留言的id，用分隔符隔开',
  `create_time` date DEFAULT NULL COMMENT '创建和修改时间',
  `sale_state` int(20) NOT NULL COMMENT '书现在的状态',
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bookloop_book
-- ----------------------------

-- ----------------------------
-- Table structure for `bookloop_liuyan`
-- ----------------------------
DROP TABLE IF EXISTS `bookloop_comment`;
CREATE TABLE `bookloop_comment` (
  `id` int(10) NOT NULL COMMENT '留言id',
  `book_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `time` int(11) NOT NULL COMMENT '可以转换为年月日时分秒',
  `content` varchar(255) NOT NULL,
  `isfirst` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是留言人的第一条留言，是则为1，不是则为0，默认为0(我觉得是不是改成这条留言是这串留言第一条)',
  `next` varchar(255) DEFAULT NULL COMMENT '回复此条留言的留言编号，以分隔符隔开',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bookloop_liuyan
-- ----------------------------

-- ----------------------------
-- Table structure for `bookloop_user`
-- ----------------------------
DROP TABLE IF EXISTS `bookloop_user`;
CREATE TABLE `bookloop_user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(21) NOT NULL,
  `user_email` varchar(30) NOT NULL,
  `user_nickname` varchar(21) NOT NULL COMMENT '用户昵称',
  `avatar_id` int(21) DEFAULT NULL COMMENT '用户头像',
  `self_info` varchar(255) DEFAULT NULL,
  `order_finish` varchar(255) DEFAULT NULL COMMENT '已完成订单',
  `order_not` varchar(255) DEFAULT NULL COMMENT '未完成订单',
  `footprint` varchar(255) DEFAULT NULL COMMENT '访问过的书籍信息，书籍id用分隔符分隔',
  `favorite` varchar(255) DEFAULT NULL COMMENT '收藏夹',
  `sale` varchar(255) DEFAULT NULL COMMENT '用户正在销售的图书',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bookloop_user
-- ----------------------------
