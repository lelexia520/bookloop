<?php
namespace Home\Model\Admin;
use Think\Model;
class UserModel extends Model {
	
}
