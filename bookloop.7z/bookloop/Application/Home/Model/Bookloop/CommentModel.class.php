<?php
namespace Home\Model\Book;
use Think\Model;
class CommentModel extends Model {
	protected $_validate = array(
// 			array('verity','require','验证码错误'),
	);
	
	
}