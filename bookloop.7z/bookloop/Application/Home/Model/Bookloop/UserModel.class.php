<?php
namespace Home\Model\Book;
use Think\Model;
class UserModel extends Model {
	protected $_validate = array(
// 			array('verity','require','验证码错误'),
			array('user_name','','账户名称已存在',0,'unique','1'),
			array('user_email','email','该邮箱已经被使用',0,'unique','1'),
			
	);
}