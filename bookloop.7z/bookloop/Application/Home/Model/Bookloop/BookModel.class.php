<?php
namespace Home\Model\Book;
use Think\Model;
class BookModel extends Model {
	protected $_validate = array(
// 			array('verity','require','验证码错误'),
			array('image','number','图片错误',0,'3'),
			array('email','email','该邮箱已经被使用',0,'unique','1'),
			array('isbn','','isbn错误',0,'regex','3'),//正则表达式验证
			
	);
	
}