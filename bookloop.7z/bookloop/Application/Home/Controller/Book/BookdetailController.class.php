<?php
namespace Home\Controller\Book;
use Think\Controller;
class BookdetailController extends Controller {
	public function index($book_id,$p=1){
// 		$this->show($content);
// 		此处是书籍的详情界面
// 		获取书籍信息
		$book = M('Book');
// 		print_r($bookid);
		$bookinfo = $book->where("book_id=$book_id")->find();
		print_r($bookinfo); echo "<br />";
// 		首先是书籍的封面
		/*$cover = new \Think\Image();
		$cover->open("$bookinfo('bookcoverurl')");
		$this->assign('cover',$cover);*/
// 		之后是各个书的其他信息
		$this->assign('bookinfo',$bookinfo);
		
// 		留言框
		$length = 1;
		$Comment = M("Comment");
		$full_where = "book_id=$book_id";
		$full_list = $Comment->where($full_where)->order('time')->/*page(I('p'.",25"))->*/select();
		$where = "book_id=$book_id AND isfirst=1";
		$list = $Comment->where($where)->order('time')->/*page(I('p'.",25"))->*/select();
		$this->assign('comment',$list);
// 		$count = $Comment->count();
		$count = sizeof($list);
// 		print_r($count);
// 		print_r($full_list);
		$Page = new \Think\Page($count,$length);
		$show = $Page->show();
		$this->assign('comment_page',$show);
// 		显示

		echo "<br />";	
		$this->display();
// 		echo "bookdetail";
	}
	public function addbookmessage() {
// 		从路由上得到
		$bookid = I('bookid');	
		$bookmessage = M("$bookid"."message");
// 		之前应该先从Middleware中checkmessage转发过来,涉及安全性，之后修改
		$message = I('bookmessage');
// 		写入数据
		
		
	}
}