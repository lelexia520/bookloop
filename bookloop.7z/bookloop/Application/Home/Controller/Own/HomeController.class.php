<?php
namespace Home\Controller\Own;
use Think\Controller;
class HomeController extends Controller {
	public function index(){
// 		$this->show($content);
// 		$user_id = session('user_id');
		$user_id = 1;
		
		$page = I('p',1);
		$offset =($page-1)*$length;
		$length = 1;
		$this->assign('page',$page);
		$this->assign('offset',$offset);
		$this->assign('length',$length);
		
		$ownbook = M('Book');
		$where ="user_id=$user_id AND sale_state=0";
		$list = $ownbook->where($where)->order('create_time')/*->page(I('p'),',10')*/->select();
// 		print_r($list);
		$this->assign('ownbook',$list);
		$count = $ownbook->count();
		$Page =new \Think\Page($count,$length);
		$show = $Page->show();
		$this->assign('ownbookpage',$show);
		
		
		$this->display();
// 		echo "ownhome";
	}
// 	这里是个人主页的'我的订单'部分 分为两块 历史与未完成
	public function order_finish($p=1){
// 		echo "order";
		$User = M('User');
		$length = 1;

		$user_id = 1;
		
		$where ="user_id=$user_id";
		$user_info = $User->where($where)->select();
// 		print_r($userinfo);

// 		实例化历史订单
		$order_finish_string =$user_info[0]['order_finish'];
// 		print_r($order_finish_string);
		$order_finish = explode('|', $order_finish_string);
		print_r($order_finish);
		$count = sizeof($order_finish);
// 		print_r($count);
		$Page = new \Think\Page($count,$length);
		$show = $Page->show();
		$this->assign('bookdetailurl','Home/Book/Bookdetail/index/book_id/');
		$this->assign('page',$p);
		$this->assign('length',$length);
		$this->assign('order_finish',$order_finish);
		$this->assign('order_finish_page',$show);
		
		$this->display();
		

	}
	public function order_not($p=1){
		$User = M('User');
		$length = 1;
		
		$user_id = 1;
		
		$where ="user_id=$user_id";
		$user_info = $User->where($where)->select();
// 		print_r($userinfo);
// 		实例化未完成订单
		$order_not_string= $user_info[0]['order_not'];
// 		print_r($order_not_string);
		$order_not= explode('|', $order_not_string);
		print_r($order_not);
		$count = sizeof($order_not);
// 		print_r($count);
		$Page = new \Think\Page($count,$length);
		$show = $Page->show();
		$this->assign('bookdetailurl','Home/Book/Bookdetail/index/book_id/');
		$this->assign('page',$p);
		$this->assign('length',$length);
		$this->assign('order_not',$order_not);
		$this->assign('order_not_page',$show);
		
		$this->display();
	}
// 	这里是个人主页的'我的足迹'(浏览历史）
	public function footprint($p=1){
// 		echo "footprint";
// 		实例化浏览历史
		$User = M('User');
		$length = 1;
		
		$user_id = 1;
		
		$where ="user_id=$user_id";
		$user_info = $User->where($where)->select();
// 		print_r($userinfo);
// 		实例化footprint
		$footprint_string= $user_info[0]['footprint'];
// 		print_r($order_not_string);
		$footprint= explode('|', $footprint_string);
		print_r($footprint);
		$count = sizeof($footprint);
// 		print_r($count);
		$Page = new \Think\Page($count,$length);
		$show = $Page->show();
		$this->assign('bookdetailurl','Home/Book/Bookdetail/index/book_id/');
		$this->assign('page',$p);
		$this->assign('length',$length);
		$this->assign('footprint',$footprint);
		$this->assign('footprint_page',$show);
		
		$this->display();
	}
// 	收藏夹
	public function favorite($p=1) {
// 		echo "favorite";
// 		实例化收藏夹
		$User = M('User');
		$length = 1;
		
		$user_id = 1;
		
		$where ="user_id=$user_id";
		$user_info = $User->where($where)->select();
// 		print_r($userinfo);
// 		实例化footprint
		$favorite_string= $user_info[0]['favorite'];
// 		print_r($favorite_string);
		$favorite= explode('|', $favorite_string);
		print_r($favorite);
		$count = sizeof($favorite);
// 		print_r($count);
		$Page = new \Think\Page($count,$length);
		$show = $Page->show();
		$this->assign('bookdetailurl','Home/Book/Bookdetail/index/book_id/');
		$this->assign('page',$p);
		$this->assign('length',$length);
		$this->assign('favorite',$favorite);
		$this->assign('favorite_page',$show);
		
		$this->display();
	}
}