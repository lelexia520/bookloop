<?php
namespace Home\Controller\Admin;
use Think\Controller;
class MainpageController extends Controller {
	public function index(){
		// 		$this->show($content);-
// 		想把搜索和分类的东西先传到中间件，再将数据传到这个主页上
// 		下面几段可能会转到中间件里面去，这样显示的东西更准确
		$Book = M('Book');
// 		$Book->select();
		$length = 1;		
		$page = I("p",1);
		$offset = ($page-1)*$length;
		$this->assign('length',$length);
		$this->assign('offset',$offset);
		$this->assign('page',$page);
		$type = I('type',0);
		$where = "type=$type";
		
		//排序应该用create_time
		if ($type==0) {
			$list = $Book->order('create_time')/*->page(I('p').",$length")*/->select();
		}else{
			$list = $Book->where($where)->order('create_time')/*->page(I('p').",$length")*/->select();
		}
		$this->assign('book',$list);
		$count = $Book->count();
// 		echo $count."<br />";
// 		print_r($list);
// 		设置页码参数
// 		$offset = (I('p')-1)*$length;
// 		$this->assign('offset',$offset);
		$Page = new \Think\Page($count,$length);
		foreach ($where as $key => $val){
			$Page->parameter[$key] = urlencode($val);
		}
		$show = $Page->show();
		$this->assign('bookpage',$show);
		
//

		$this->display();
// 		echo "Mainpage";
	}
}