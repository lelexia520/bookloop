<?php
namespace Home\Controller\Admin;
use Think\Controller;
class SigninController extends Controller {
	public function index(){
		// 		$this->show($content);
		$this->assign('signin',U('Home/Admin/signin/check'));
		$this->assign('signup',U('Home/Admin/signup/index'));
		$this->display();
// 		echo "Signin";
	}
// 	检查并登陆
	public function check(){
		$emailname = I('emailname');
		$password = I('password');
// 		不知道用的啥登录
// 		$User = new Home\Model\Admin\UserModel();


		
// 		返回结果
		$auth=U('Home/Middleware/Authenticate/auth');
		$url=U('Home/Admin/Mainpage/index');
		if ($result){
			redirect($auth,$url,3,'正在登陆');
		}
	}
}