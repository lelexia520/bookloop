<?php
namespace Home\Controller\Middleware;
use Think\Controller;
class CheckController extends Controller{
	public function checkpassword($password){
		
	}
	public function checkemail(){
		
	}
	public function checkmessage() {
		;
	}
}