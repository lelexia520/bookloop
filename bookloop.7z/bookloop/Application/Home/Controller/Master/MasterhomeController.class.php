<?php
namespace Home\Controller\Master;
use Think\Controller;
class MasterhomeController extends Controller {
	public function index(){
		// 		$this->show($content);
		// 		$this->display();
		echo "masterhome";
	}
}