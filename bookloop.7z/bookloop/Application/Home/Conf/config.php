<?php
return array(
	//'配置项'=>'配置值'
	'CONTROLLER_LEVEL'      =>  2,
	// URL变量绑定到操作方法作为参数
	'URL_PARAMS_BIND'       =>  true, 
// 		设置数据库
	'DB_TYPE'               => 'mysql',
// 		设定数据表前缀
	'DB_PREFIX'             => 'bookloop_',
	'DB_HOST' 				=> '127.0.0.1',
	'DB_NAME'				=> 'bookloop',
	'DB_USER'				=> 'root',
	'DB_PWD'				=> 'root',
	'DB_PORT'				=> '3306',
	'DB_DSN'				=> '',
	'DB_CHARSET'			=> 'utf8',
	'DB_DEBUG'				=> 'true'
	
	
);