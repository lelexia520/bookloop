﻿项目目录


在需要获取用户信息时，专门写了个函数，存在中间件文件夹里面

= -= 
i find i can't input chinese= - =.....

use dunction password in widdleware to check password