<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>favorite</title>
</head>
<body>
收藏夹<br />
	<?php $__FOR_START_9192__=$length*($page-1);$__FOR_END_9192__=$length*$page;for($i=$__FOR_START_9192__;$i < $__FOR_END_9192__;$i+=1){ $url = U("$bookdetailurl$favorite[$i]"); ?>
		书<?php echo ($i+1); ?>  :<a href="<?php echo ($url); ?>"> <?php echo ($favorite[$i]); ?> </a> <br /><?php } ?>
<?php echo ($favorite_page); ?>
</body>
</html>