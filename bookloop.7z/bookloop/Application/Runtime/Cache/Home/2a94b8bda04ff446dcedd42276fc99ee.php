<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<p>前面应该有一些关于这个项目的介绍</p>
<form action="<?php echo ($signincheck); ?>" method="post">
	<p>email&name:<input type='text' name='emailname' /></p>
	<!--<p>nickname:<input type='text' name='nickname' /></p>-->
	<p>password:<input type='password' name='password' /></p>
    <input type='submit' name='submit' value='signin' />
</form>
<a href='<?php echo ($signup); ?>'>这里注册</a>
<a href='<?php echo ($mainpageun); ?>'>随便看看</a><br />
</body>
</html>