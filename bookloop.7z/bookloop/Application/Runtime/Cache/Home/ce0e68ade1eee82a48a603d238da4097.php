<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>order</title>
</head>
<body>
	订单历史<br />
	<?php $__FOR_START_23295__=$length*($page-1);$__FOR_END_23295__=$length*$page;for($i=$__FOR_START_23295__;$i < $__FOR_END_23295__;$i+=1){ $url = U("$bookdetailurl$order_finish[$i]"); ?>
		书<?php echo ($i+1); ?>  :<a href="<?php echo ($url); ?>"> <?php echo ($order_finish[$i]); ?> </a> <br /><?php } ?>
	
	<?php echo ($order_finish_page); ?>
	
	page:<?php echo ($page); ?>
	length:<?php echo ($length); ?>
	
	
</body>
</html>