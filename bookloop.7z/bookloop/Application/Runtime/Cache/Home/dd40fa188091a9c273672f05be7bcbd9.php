<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
浏览记录<br />
	<?php $__FOR_START_29999__=$length*($page-1);$__FOR_END_29999__=$length*$page;for($i=$__FOR_START_29999__;$i < $__FOR_END_29999__;$i+=1){ $url = U("$bookdetailurl$footprint[$i]"); ?>
		书<?php echo ($i+1); ?>  :<a href="<?php echo ($url); ?>"> <?php echo ($footprint[$i]); ?> </a> <br /><?php } ?>
<?php echo ($footprint_page); ?>

</body>
</html>