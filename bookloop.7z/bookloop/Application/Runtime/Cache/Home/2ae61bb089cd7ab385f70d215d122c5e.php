<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>order_not</title>
</head>
<body>
未完成订单<br />
	<?php $__FOR_START_24809__=$length*($page-1);$__FOR_END_24809__=$length*$page;for($i=$__FOR_START_24809__;$i < $__FOR_END_24809__;$i+=1){ $url = U("$bookdetailurl$order_not[$i]"); ?>
		书<?php echo ($i+1); ?>  :<a href="<?php echo ($url); ?>"> <?php echo ($order_not[$i]); ?> </a> <br /><?php } ?>
<?php echo ($order_not_page); ?>
</body>
</html>