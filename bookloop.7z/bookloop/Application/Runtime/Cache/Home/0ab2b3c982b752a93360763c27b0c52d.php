<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

书名:<?php echo ($bookinfo['name']); ?><br />
简介:<?php echo ($bookinfo['description']); ?><br />
作者:<?php echo ($bookinfo['author']); ?><br />
<br /><br /><br />
<?php echo ($comment_page); ?>
<form action="Home/Book/Bookdetail/addbookmessage" method="post">
	<input type='text' name='bookmessage' value='这里输入留言' />
	<input type='submit' value='提交' />
</form>

提交后会先去是否登录的中间件检查 再去checkmessage检查
</body>
</html>