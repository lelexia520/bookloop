<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Home</title>
</head>
<body>
	个人中心主页<br />
<?php if(is_array($ownbook)): $i = 0; $__LIST__ = array_slice($ownbook,$offset,$length,true);if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>书名:<?php echo ($vo["name"]); ?> <br /><?php endforeach; endif; else: echo "" ;endif; ?>
<?php echo ($ownbookhistory); ?>
page:<?php echo ($page); ?><br />
offset:<?php echo ($offset); ?><br />
length:<?php echo ($length); ?><br />
</body>
</html>