<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>order</title>
</head>
<body>
	订单
	
	<?php echo ($order_finish_page); ?>
	
	<?php echo ($order_not_page); ?>
</body>
</html>